#!/bin/bash

./capture_interface_pcap.sh -i ens33 -d pcap -Z "$(id -nu 1000)"
