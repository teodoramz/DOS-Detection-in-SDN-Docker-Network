export JAVA_OPTS="-Xms512m -Xmx8g"
./convert_pcap_csv.sh slice_%03d_00000_20250616193503.pcap
./convert_pcap_csv.sh slice_%03d_00001_20250616193533.pcap
./convert_pcap_csv.sh slice_%03d_00002_20250616193603.pcap
./convert_pcap_csv.sh slice_%03d_00003_20250616193633.pcap
./convert_pcap_csv.sh slice_%03d_00004_20250616193703.pcap
./convert_pcap_csv.sh slice_%03d_00005_20250616193733.pcap
./convert_pcap_csv.sh slice_%03d_00006_20250616193803.pcap
./convert_pcap_csv.sh slice_%03d_00007_20250616193833.pcap
./convert_pcap_csv.sh slice_%03d_00008_20250616193903.pcap
./convert_pcap_csv.sh slice_%03d_00009_20250616193933.pcap
./convert_pcap_csv.sh slice_%03d_00010_20250616194003.pcap
./convert_pcap_csv.sh slice_%03d_00011_20250616194033.pcap
./convert_pcap_csv.sh slice_%03d_00012_20250616194103.pcap
./convert_pcap_csv.sh slice_%03d_00013_20250616194133.pcap
./convert_pcap_csv.sh slice_%03d_00014_20250616194203.pcap
./convert_pcap_csv.sh slice_%03d_00015_20250616194233.pcap
./convert_pcap_csv.sh slice_%03d_00016_20250616194303.pcap
./convert_pcap_csv.sh slice_%03d_00017_20250616194333.pcap
./convert_pcap_csv.sh slice_%03d_00018_20250616194403.pcap
./convert_pcap_csv.sh slice_%03d_00019_20250616194433.pcap

