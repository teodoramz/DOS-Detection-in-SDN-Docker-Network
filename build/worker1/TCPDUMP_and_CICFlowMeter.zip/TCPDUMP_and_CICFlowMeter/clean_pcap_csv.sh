#!/bin/bash

rm -f tmp/*.*
rm -f pcap/*.pcap
rm -f csv/*.csv
rm -f csv/*/*.csv
