#!/bin/bash

watch -n1 'ls -lh pcap tmp csv'
